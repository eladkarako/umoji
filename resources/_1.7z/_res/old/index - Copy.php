<!doctype html>
<html dir="ltr" class="notranslate skiptranslate">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta name="description" content="Unicode Emoji - Easy Copy, No Squares (Only Valid Images for Courier New), No Bull$hit.">
<meta name="keywords" content="Unicode,Emoji">
<meta http-equiv="content-script-type" content="application/javascript;charset=UTF-8">
<!-- available at: http://umoji.eladkarako.com and http://eladkarako.github.io/umoji.eladkarako.com -->
<title>U(nicode E)moji</title>
<style>
  *{
    text-size-adjust: 100%;
    box-sizing: border-box;
  }
  html {
    /* this helps to override bi-directional-unicode-chars (if any) */
    direction: ltr;
    text-align: left;
    unicode-bidi: bidi-override;

    font: 40pt/80pt 'Courier New', monospace;
    box-sizing: border-box;

    text-size-adjust: 100%;
    box-sizing: border-box;

    -webkit-font-smoothing: none;
    text-rendering: optimizeSpeed;
    
    font-stretch: ultra-expanded;
    
    font-feature-settings: "kern" 0;
    font-kerning: none !important;
  }
  html,body{
    height:100%;
  }
  html,body,[data-role]{
    overflow:hidden;
    width:100%; 
    padding:0; 
    margin:0;
  }
  body,[data-role], [data-role]:hover, [data-role]:active, [data-role]:focus{
    border-collapse:collapse;
    border:1px solid rgba(0,0,0,.3); 
    outline:1px solid rgba(0,0,0,.3);
  }

  /* height */
  [data-role="header"],[data-role="footer"]{ height:7%; background-color:#E5E3C1;}
  [data-role="content"]{height:86%;}
  
  /* shadow */
  [data-role="header"]{ box-shadow: 0 5px 10px rgba(67,67,177,.2); }
  [data-role="footer"]{ box-shadow: 0 -5px 10px rgba(67,67,177,.2); }

  /* code box feel */
  [data-role="content"]{
    white-space: pre-line;
    word-break: break-all;
    overflow-x: hidden;
    overflow-y: scroll;
  }

  [hide]{ display: none; }

  [c]{
    display: inline-block;
    vertical-align: text-bottom;
    padding: 6pt;
    margin: 6pt;
    height: 60pt;
    width: 50pt;
  }
  [c]:nth-child(even) { background: none #FEE7AF; }
  [c]:nth-child(odd)  { background: none #EAD6F2; }

  [message]:not([message=""]):before {
    content: "☞︎"attr(message);
  }
</style>
</head><body hide>
<div data-role="header"></div>
<div data-role="content" contenteditable="true" message=""></div>
<div data-role="footer"></div>
<script async defer src="data:application/javascript;base64,KGZ1bmN0aW9uKGJvZHksIHNjcmlwdCl7CiAgc2NyaXB0LnNldEF0dHJpYnV0ZSgic3JjIiwgImh0dHBzOi8vd3d3Lmdvb2dsZS1hbmFseXRpY3MuY29tL2FuYWx5dGljcy5qcyIpOwogIHNjcmlwdC5vbmxvYWQgPSBmdW5jdGlvbigpewogICAgaWYoInVuZGVmaW5lZCIgPT09IHR5cGVvZiB3aW5kb3cuZ2EpIHJldHVybjsKICAgIHdpbmRvdy5nYSgiY3JlYXRlIiwgIlVBLTcyMjI5OTYxLTEiLCAiYXV0byIpOwogICAgd2luZG93LmdhKCJyZXF1aXJlIiwgImxpbmtpZCIsICJsaW5raWQuanMiKTsKICAgIHdpbmRvdy5nYSgicmVxdWlyZSIsICJkaXNwbGF5ZmVhdHVyZXMiKTsKICAgIHdpbmRvdy5nYSgic2VuZCIsICJwYWdldmlldyIpOwogIH07CiAgYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpOwp9KApkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCJib2R5IikKLGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoInNjcmlwdCIpCikpOwovKiBleHBsaWNpdCBkaXJlY3Rpb24gY2hhcnMgdG8gZGVsZXRlOiBcdTIwNjYgXHUyMDY3IFx1MjA2OCBcdTIwNjkgXHUyMDBFIFx1MjAwRiBcdTA2MUMgXHUyMDJBLCBcdTIwMkIgXHUyMDJDIFx1MjAyRCBcdTIwMkUgKi8K"></script>
<script>
(function(header, content, footer, xhr){
  "use strict";

  content.setAttribute("message", "start");

  xhr.onprogress = function(ev){
    if (false === ev.lengthComputable) return;

    /* content.msg is just a temp storage.. */
    content.msg = "Recived " + xhr.responseText.length + " characters, [" + String(Math.round(Number(ev.loaded / ev.total).toFixed(3) * 100)) + "%]";
    content.setAttribute("message", content.msg);
    console.log(content.msg);
  };

  xhr.onreadystatechange = function(ev){
    content.msg = XMLHttpRequest.DONE              === xhr.readyState ? "DONE"              :
                  XMLHttpRequest.HEADERS_RECEIVED  === xhr.readyState ? "HEADERS RECEIVED"  :
                  XMLHttpRequest.LOADING           === xhr.readyState ? "LOADING"           :
                  XMLHttpRequest.OPENED            === xhr.readyState ? "OPENED"            :
                  XMLHttpRequest.UNSENT            === xhr.readyState ? "UNSENT"            :
                  "UNKNOWN";
    content.setAttribute("message", content.msg);
    console.log(content.msg);
    
    if(XMLHttpRequest.DONE !== xhr.readyState) return;

    /* cleanup */
    content.msg = "";
    content.setAttribute("message", "");
    
    content.style.display = "none";
    content.innerHTML = "<span c>" + xhr.response.replace(/\n/g,"</span><span c>") + "</span>";
    //content.innerHTML = "<span c>" + xhr.response.replace(/\n/g, "\uFE0E" + "</span>" + "\uFE0E" + "<span c>") + "</span>";
    setTimeout(function(){
      content.style.display = "block";
    },100);
  };

  xhr.open("POST", "content.json", true);
  xhr.responseType = "text";
  xhr.overrideMimeType("text/plain;charset=UTF-8");
  xhr.send();

}(
  document.querySelector('[data-role="header"]')
, document.querySelector('[data-role="content"]')
, document.querySelector('[data-role="footer"]')
, new XMLHttpRequest()
));
</script>
<script>
/*ease up rendering of a lot (!) of text, on supported platforms..*/
  window.onload = function(){
                    document.body.removeAttribute("hide");
                  };
</script>
</body></html>
