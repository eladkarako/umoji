<h1>A redesign of the original umoji.eladkarako.com</h1>

Designed for fast load, and fast rendering.

buttons are created using an external resource called <code>characters.js</code>
which is essentially a script with a JSON (array...) loading the content into the global-scope,
resources and scripts are pre-cached (and even pre-rendered in Chrome).

The copy is done by clicking a button,
there is a minimal reflow, and the "value" of each button is using CSS3 to be redrawn,
which is a slightly better way than the original, but since the CSS3 content is uncopyable,
the javascript assigning of a copy action to each button is needed,
I use a passive click handler, also a ctrl+click will disable the button so the following code
could help me regenerate a "json" of fixed umoji icons for the next time
(without the buttons that were disabled in previous session).

```js
NodeList.prototype.map = Array.prototype.map;
document.querySelectorAll('[c]:not([disabled])')
        .map(function(element){return element.character.replace(/\uFE0E/g,"");})
        .sort()
        .reverse()
        .map(function(s){return escape(s)})
        .join("\n")
        .replace(/\%uFE0E/g,"")
        .replace(/\%u/g,"\\u")
        .replace(/^/gm,',"')
        .replace(/$/gm,'"')
        ;
```

This makes the page slightly worse value than the original umoji page,
since it is rendered dynamically, while the original page is perfectly static...
 
this also means that the order of the icons is natural (~about the order in the Unicode/ASCII table),
while in the original page, it was nicely put into groups,
and although it is possible to generate a JSON with sub-groups, it is no longer optimal value of code/usage (keep it simple :])

....WorkInProgress...
