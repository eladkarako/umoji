NodeList.prototype.forEach = Array.prototype.forEach;


function copy_str(str){
  var textarea = document.querySelector("textarea");
  
  self.getSelection().removeAllRanges();
  textarea.value = str;
  textarea.style.display = "inline";
//textarea.focus();
  textarea.select();
  document.execCommand("copy");
//textarea.blur();
  textarea.style.display = "none";
}


function click_handler(ev){
  var element, value;
  
  element = ev.target || ev.path[0];
  value   = element.character
                   .replace(/\uFE0E/g, "") + "\uFE0E";

  copy_str(value);
}


document.querySelector("body").innerHTML =  '<span c="'
                                          + self.characters.join("\uFE0E" + '"></span><span c="') 
                                          + "\uFE0E" 
                                          + '"></span>';


document.querySelector("body").appendChild(
                                 document.createElement("textarea")
                               );


document.querySelectorAll("[c]")
        .forEach(function(element){
                  element.character = element.getAttribute("c").replace(/\uFE0E/g, "");
                  element.addEventListener("click", click_handler, false);
        });

