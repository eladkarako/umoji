/* ╔═════════════════╗
   ║ Unicode Is Fun! ║
   ╟─────────────────╢
   ╚═════════════════╝
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ */

(function(HEBREW_NIKUD_CHARACTERS, window, document, textarea, keyboard, button_copy){ "use strict";

  function click_handler_key(ev){
    var target           = ev.target || ev.path[0]
       ,character        = target.character
       ,cursor_position
       ,part1
       ,part2
       ;

    //navigator.vibrate(20);  //clicking keys has feedback (feel/haptic-feed).
/*
 הסמן אחרי ה-א
 אלעד +  ֶ
console: א 1 לעד 3

הסמן אחרי ה-ל
 אֶלעד +  ְ
console: אֶל 3 עד 2
*/
    textarea.focus();
    cursor_position = textarea.selectionEnd;

    part1 = textarea.value.substring(0,textarea.selectionStart);
    part2 = textarea.value.substring(textarea.selectionStart);
    //console.log(part1,part1.length,part2,part2.length);
    textarea.value =  part1 + character.content + part2;

    cursor_position = cursor_position + character.content.length;

    textarea.selectionStart = cursor_position; //restore cursor (near original) position
    textarea.selectionEnd   = cursor_position;
    
    return true; //maximum compatibility.
  }
  
  HEBREW_NIKUD_CHARACTERS.forEach(function(character){
    var key, description;

    if("SPACER" === character.content){
      keyboard.appendChild(document.createElement("hr"));
      return;
    }
    
    var tmp = document.createElement("TEMP");
    tmp.innerHTML = '<span key description button title="##DESCRIPTION##">##CONTENT##</span>'
                                         .replace(/##CONTENT##/,     "\u00A0" + character.content + "\u00A0")
                                         .replace(/##DESCRIPTION##/,                   character.description)
                                         ;
    tmp = tmp.querySelector("span");
    tmp.addEventListener("click", click_handler_key, {capture: false, passive: true});
    tmp.character = character;

    keyboard.appendChild(tmp);
  });


  function click_handler_buttoncopy(ev){
    var target = ev.target || ev.path[0];
    target.removeAttribute("success-state");

    window.getSelection().removeAllRanges();
    textarea.focus();

    if("" === textarea.value) return false;

    try{
      textarea.select();
      document.execCommand("copy");
      target.setAttribute("success-state", "success");
    }catch(err){
      target.setAttribute("success-state", "failure");
    }

    setTimeout(function(){
      target.removeAttribute("success-state");
    },350);
  }

  button_copy.addEventListener("click", click_handler_buttoncopy, {capture: false, passive: true});


}(
  [ {content:"\u05B0", description:"שְׁוָא‎"}                  //HEBREW_NIKUD_CHARACTERS   https://he.wikipedia.org/wiki/טעמי_המקרא
   ,{content:"\u05B1", description:"חֲטַף סֶגּוֹל‎"}
   ,{content:"\u05B2", description:"חֲטַף פַּתַח‎"}
   ,{content:"\u05B3", description:"חֲטַף קָמָץ‎"}
   ,{content:"\u05B4", description:"חִירִיק‎"}
   ,{content:"\u05B5", description:"צֵירֵי‎"}
   ,{content:"\u05B6", description:"סֶגּוֹל‎"}
   ,{content:"\u05B7", description:"פַּתַח‎"}
   ,{content:"\u05C7", description:"קָמַץ גָּדוֹל‎"}
   ,{content:"\u05B8", description:"קָמַץ קָטָן‎"}
   ,{content:"\u05C1", description:"שִׁי'ן יְמָנִית‎"}
   ,{content:"\u05C2", description:"שִׁי'ן שְׂמָאלִית‎"}
   ,{content:"\u05B9", description:"חוֹלָם‎"}
   ,{content:"\u05BA", description:"חולם חסר ל-ו"}

   ,{content:"\u05BC", description:"דָּגֵשׁ‎/מפיק"}
   ,{content:"\u05BB", description:"קֻבּוּץ‎"}
   ,{content:"\u05BF", description:"רָפֵא‎"}
   ,{content:"\u05BC", description:"שׁוּרוּק‎"}

   ,{content:"SPACER", description:""}

   ,{content:"\u05BE", description:"מקף"}
   ,{content:"\u05C3", description:"סוף פסוק"}
   ,{content:"\u05C4", description:"נקודה עילית"}
   ,{content:"\u05C5", description:"נקודה תחתית"}
   ,{content:"\u05C6", description:"נוּן הפוכה"}

   ,{content:"SPACER", description:""}

   ,{content:"\u05BD", description:"סוֹף פָּסֽוּק"}
   ,{content:"\u0591", description:"אֶתְנַחְתָּ֑א"}
   ,{content:"\u0592", description:"סְגוֹלְתָּא֒"}
   ,{content:"\u0593", description:"שַׁלְשֶׁ֓לֶת"}
   ,{content:"\u0594", description:"זָקֵף קָט֔וֹן"}
   ,{content:"\u0595", description:"זָקֵף גָּד֕וֹל"}
   ,{content:"\u0596", description:"טַרְחָ֖א"}
   ,{content:"\u0597", description:"רְבִ֗יעַ"}
   ,{content:"\u0598", description:"זַרְקָא֮"}
   ,{content:"\u0599", description:"קַדְמָא֙"}
   ,{content:"\u0599\u05A8", description:"תּרֵ֨י קַדְמִין֙"}
   ,{content:"\u05A8", description:"אַזְלָ֨א"}
   ,{content:"\u05A9", description:"יְ֚תִיב"}
   ,{content:"\u059B", description:"תְּבִ֛יר"}
   ,{content:"\u05A1", description:"פָּזֵר גָּד֡וֹל"}
   ,{content:"\u059F", description:"קַרְנֵי פָרָ֟ה"}
   ,{content:"\u05A0", description:"תַּ֠לְשָׁא"}
   ,{content:"\u059C", description:"גְּרִ֜ישׁ"}
   ,{content:"\u059E", description:"שְׁנֵי גְרִישִׁ֞ין"}
   ,{content:"\u05C0", description:"פסק"}
   ,{content:"\u05A3\u05C0", description:"פָּסֵ֣ק׀"}
   ,{content:"\u05A5", description:"מַאֲרִ֥יךְ"}
   ,{content:"\u05A3", description:"שׁוֹפָר הוֹלֵ֣ךְ"}
   ,{content:"\u05A4", description:"שׁוֹפָר מְהֻפָּ֤ךְ"}
   ,{content:"\u05A7", description:"דַּרְגָּ֧א"}
   ,{content:"\u05A9", description:"תִּלְשָׂא֩"}
   ,{content:"\u05A6", description:"תְּרֵי טַעֲמֵ֦י"}
   ,{content:"\u05AA", description:"יֵרֶח בֶּן יוֹמ֪וֹ"}
   ,{content:"\u059D", description:"גֵרֵשׁ מוּקְדָם֝"}
   ,{content:"\u059D", description:"גֵרֵשׁ מוּקְדָם֝"}
   ,{content:"\u05A2", description:"אתנח הפוך֢"}
   ,{content:"\u05AB", description:"עוֹלֶה֫"}
   ,{content:"\u05AC", description:"עִלוּי֬"}
   ,{content:"\u05AD", description:"דחי֭"}
   ,{content:"\u05AE", description:"צִנּוֹרִת֘"}

   ,{content:"SPACER", description:""}

   ,{content:"\u05F0", description:"וו כפולה"}
   ,{content:"\u05F1", description:"וו ויוד"}
   ,{content:"\u05F2", description:"יוד כפולה"}
   ,{content:"\u05F3", description:"גרש"}
   ,{content:"\u05F4", description:"גרשיים"}

   ,{content:"SPACER", description:""}

   ,{content:"\u05D0", description:"אָלֶף"}
   ,{content:"\u05D1", description:"בֵּית"}
   ,{content:"\u05D2", description:"גִּימֶל"}
   ,{content:"\u05D3", description:"דָּלֶת"}
   ,{content:"\u05D4", description:"הֵא"}
   ,{content:"\u05D5", description:"וָיו"}
   ,{content:"\u05D6", description:"זַיִן"}
   ,{content:"\u05D7", description:"חֵית"}
   ,{content:"\u05D8", description:"טֵית"}
   ,{content:"\u05D9", description:"יוֹד"}
   ,{content:"\u05DA", description:"כָּף סוֹפִית"}
   ,{content:"\u05DB", description:"כָּף"}
   ,{content:"\u05DC", description:"לָמֶד"}
   ,{content:"\u05DD", description:"מֵם סוֹפִית"}
   ,{content:"\u05DE", description:"מֵם"}
   ,{content:"\u05DF", description:"נוּן סוֹפִית"}
   ,{content:"\u05E0", description:"נוּן"}
   ,{content:"\u05E1", description:"סָמֵך"}
   ,{content:"\u05E2", description:"עַיִן"}
   ,{content:"\u05E3", description:"פֵּא סוֹפִית"}
   ,{content:"\u05E4", description:"פֵּא"}
   ,{content:"\u05E5", description:"צָדִי סוֹפִית"}
   ,{content:"\u05E6", description:"צָדִי"}
   ,{content:"\u05E7", description:"קוֹף"}
   ,{content:"\u05E8", description:"רֵיִש"}
   ,{content:"\u05E9", description:"שִׁין"}
   ,{content:"\u05EA", description:"תָּו"}
  ]
, self
, self.document
, self.document.querySelector("textarea")
, self.document.querySelector("[keyboard]")
, self.document.querySelector("[copy]")
));

/* - - - */

(function(window, document, body, script, UA_ID){ "use strict";
  if(null === body) return;
  script.setAttribute("src", "https://www.google-analytics.com/analytics.js");
  script.setAttribute("async",                       "");
  script.setAttribute("defer",                       "");
  script.onload = function(){
    if("undefined" === typeof window.ga) return;
    window.ga("create", UA_ID, "auto");
    window.ga("require", "displayfeatures");
    window.ga("send", "pageview");
  };
  body.appendChild(script);
}(
  self
, self.document
, self.document.querySelector("body")
, self.document.createElement("script")
, "UA-88344105-6"
));
