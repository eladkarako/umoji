<h1><img width="64" height="64" src="resources/icon.png"/> Nikud Web-Page, Keyboard Like.</h1>

Easy type, easy copy.

<img alt="" src="resources/screenshot_1.png" title="Smartphones"/>

<hr/>

Available at: <a href="https://eladkarako.github.io/nikud"><code>https://eladkarako.github.io/nikud</code></a> and <a href="http://nikud.eladkarako.com"><code>nikud.eladkarako.com</code></a> <em>(shorter to type...)</em>.

<hr/>

I really love using <a href="https://play.google.com/store/apps/details?id=com.touchtype.swiftkey" title="https://play.google.com/store/apps/details?id=com.touchtype.swiftkey"><em><strong>SwiftKey</strong></em></a>!

It really is a great little keyboard for Android,
but it lacks the Hebrew punctuation.

<strong><em>Nikud</em></strong> website is just here to help you <strong>type</strong>, and <strong>copy</strong>, nothing sophisticated.

<strong><em>Nikud</em></strong> is mobile friendly,
allows a very-convenient Hebrew typing and <strong><em>one-click</em> copy</strong> button.

If you find any issues, have a requirement
or suggestion <sub>(or even just want to say hi)</sub>
Open up a new issue: <a href="https://github.com/eladkarako/nikud/issues/new">https://github.com/eladkarako/nikud/issues/new</a>.

<hr/>

<h2>Notes (Technical)</h2>

<ul><li>
  <h3>On your PC?</h3>

  <a href="http://nikud.eladkarako.com"><strong>Nikud</strong> website</a> will work just fine on your PC too..

  <img alt="" src="resources/screenshot_2.png" title="PC"/>

  but it will probably be faster if you'll learn the <code>[CAPS-LOCK],[ALT]+[SHIFT],[SHIFT]+(..top-line-numbers..)</code> it will allow you to type using just the keyboard itself, it will probably also work on your phone if you'll have a USB-keyboard attached to your phone, if it has a OTG-USB support.
  <ul>
  <li><a href="http://support.microsoft.co.il/how-to-add-hebrew-spelling-marks/">http://support.microsoft.co.il/how-to-add-hebrew-spelling-marks/</a></li>
  <li><a href="http://support.microsoft.co.il/windows-8-hebrew-spelling-key-board/">http://support.microsoft.co.il/windows-8-hebrew-spelling-key-board/</a></li>
  </ul>
</li></ul>


<ul><li>
  <h3>How it works?</h3>

  clicking the "keys" in the lower-sction will add the <strong>Unicode value</strong> of the Hebrew character, at the cursor position in the textarea,

  <img src="resources/internal_code_1.png"/>
</li></ul>



<strong>but</strong> it will also keep the current cursor-position <sub>(+1 or +2 depands on the length of the addition).</sub>
Here is a little snippet that shows how it is done:

```js
  function click_handler(ev){
    var target           = ev.target || ev.path[0]
       ,character        = target.character
       ,cursor_position
       ,part1
       ,part2
       ;

    //navigator.vibrate(20);  //clicking keys has feedback (feel/haptic-feed).
/*
 הסמן אחרי ה-א
 אלעד +  ֶ
console: א 1 לעד 3

הסמן אחרי ה-ל
 אֶלעד +  ְ
console: אֶל 3 עד 2
*/
    textarea.focus();
    cursor_position = textarea.selectionEnd;

    part1 = textarea.value.substring(0,textarea.selectionStart);
    part2 = textarea.value.substring(textarea.selectionStart);
    console.log(part1,part1.length,part2,part2.length);
    textarea.value =  part1 + character.content + part2;

    cursor_position = cursor_position + character.content.length;

    textarea.selectionStart = cursor_position; //restore cursor (near original) position
    textarea.selectionEnd   = cursor_position;
    
    return true; //maximum compatibility.
  }
```

<hr/>

A lot of page-elements were set in both CSS-zero and direction-attribute for <code>RTL</code>-writing direction, and <code>Hebrew</code> and <code>he-IL</code> language specification. You can still type bi-(or more)-directional languages such as Hebrew/English, it simply helps the overall feel to favor the Hebrew content, correctly. :]

<hr/>

<h3>This page is hosted on Github: <a href="https://eladkarako.github.io/nikud">https://eladkarako.github.io/nikud</a> but also available on my domain: <a href="http://nikud.eladkarako.com">http://nikud.eladkarako.com</a>.</h3>
<h3>It really just loads the GitHub page in an iframe, so it is still from HTTPS and fast</h3>
<h3>You might find it useful to type just <code>nikud.eladkarako.com</code> in your mobile-browser, since it is shorter.</h3>