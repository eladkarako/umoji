self.characters = [
 "\u05D0"
,"\u05D1"
,"\u05D2"
,"\u05D3"
]